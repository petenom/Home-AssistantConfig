pyfttt is a package for interacting with the IFTTT Maker Channel. Currently, it only supports sending events, but a lightweight web server that receives actions may be added in the future.


